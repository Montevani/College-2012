#include <iostream.h> 
#include<conio.h>

int main() 
{ 
  char nome[20] = "Eduardo Bayer";
  
  cout<< nome + 6 << endl;
  cout<< nome << endl;
  cout << nome + 3;
  cout<<"\nErrei!";
  getch();
} 
